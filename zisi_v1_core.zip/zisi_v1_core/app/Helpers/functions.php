<?php
declare(strict_types=1);
function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $path = '/'): string {
    $base = rtrim((string)($_ENV['APP_URL'] ?? ''), '/');
    return $base . '/' . ltrim($path, '/');
}
function redirect(string $path): never { header('Location: ' . url($path)); exit; }
function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void {
    $sent = (string)($_POST['_csrf'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) { http_response_code(419); exit('Your session expired. Please reload and try again.'); }
}
function current_user_id(): ?int { return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null; }
function current_user(): ?array {
    static $loaded = false; static $user = null;
    if ($loaded) return $user;
    $loaded = true;
    if (!current_user_id()) return null;
    $stmt = db()->prepare('SELECT id, username, role, is_verified, status FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([current_user_id()]);
    $user = $stmt->fetch() ?: null;
    if ($user && $user['status'] !== 'active') { $_SESSION = []; session_destroy(); return null; }
    return $user;
}
function require_login(): void { if (!current_user()) redirect('/login.php'); }
