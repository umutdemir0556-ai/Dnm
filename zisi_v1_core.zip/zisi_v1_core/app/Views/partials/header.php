<?php $navUser = current_user(); ?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#10121b">
  <title><?= e($pageTitle ?? 'Zisi') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('/assets/css/app.css')) ?>">
</head>
<body>
<header class="topbar"><a class="brand" href="<?= e(url('/')) ?>"><span class="brand-mark">z</span><span>zisi</span></a><nav><?php if ($navUser): ?><a href="<?= e(url('/profile.php')) ?>">Profile</a><?php else: ?><a href="<?= e(url('/login.php')) ?>">Sign in</a><?php endif; ?></nav></header>
