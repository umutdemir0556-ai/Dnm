# Zisi V1 Core

Invitation-only social network starter built with PHP 8.1+, MySQL 8+, PDO and vanilla CSS/JavaScript.

## Included in this first development package
- Original dark visual identity and responsive landing page
- Invitation-code registration
- Login/logout with session regeneration
- Password hashing
- CSRF tokens on forms
- PDO prepared statements
- Basic user profile screen
- Initial relational database schema for future modules
- CLI-only admin account creation script

## Requirements
- PHP 8.1+ with PDO MySQL
- MySQL 8.0+
- Apache or Nginx
- HTTPS in production

## Setup
1. Create a MySQL database/user, or import `database/schema.sql` using a MySQL account allowed to create databases.
2. Copy `.env.example` to `.env` and set database credentials and `APP_URL`.
3. Point the web server document root to the `public/` directory. Do not expose the project root.
4. Ensure `storage/` is writable by PHP if you add logging/uploads later.
5. Create the first administrator from the project root:
   `php scripts/create_admin.php adminname admin@example.com 'Use-A-Long-Unique-Password'`
6. Generate an invitation code and store only its SHA-256 hash in the database. Example (run locally):
   `php -r 'echo strtoupper(bin2hex(random_bytes(8))), PHP_EOL;'`
   Then insert the hash of that code:
   `php -r '$c=$argv[1]; echo hash("sha256",$c), PHP_EOL;' YOUR_CODE`
   SQL:
   `INSERT INTO invitations (code_hash, created_by, max_uses, uses_count, status, expires_at, created_at) VALUES ('HASH_HERE', NULL, 1, 0, 'active', DATE_ADD(NOW(), INTERVAL 30 DAY), NOW());`
   Replace `HASH_HERE` with the generated SHA-256 hash and share the raw code privately with the invitee.
7. Run locally:
   `php -S 127.0.0.1:8000 -t public`

## Important deployment notes
- Use HTTPS.
- Keep `.env`, `database/`, `scripts/`, `inc/`, `config/`, `app/` and `storage/` outside the public document root.
- Configure production error logging; never enable `APP_DEBUG=true` publicly.
- Add rate limiting, email verification, password reset, account recovery, moderation workflows and security tests before opening the service to real users.
- The schema includes future tables, but follow, messaging, notifications and admin UI are not implemented in this core milestone yet.

## Next milestone
Build the admin interface for invitation creation/revocation and user management, then implement profile editing and the follow graph.
