<?php
declare(strict_types=1);
define('APP_ROOT', dirname(__DIR__));
date_default_timezone_set('UTC');

$envFile = APP_ROOT . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($value);
    }
}
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_name('zisi_session');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $isHttps, 'httponly' => true, 'samesite' => 'Lax']);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

require APP_ROOT . '/app/Helpers/functions.php';
require APP_ROOT . '/config/database.php';

if (($_ENV['APP_DEBUG'] ?? 'false') !== 'true') {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
}
