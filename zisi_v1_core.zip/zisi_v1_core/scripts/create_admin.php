<?php
declare(strict_types=1);
// Run from CLI only: php scripts/create_admin.php adminname admin@example.com 'LongPasswordHere'
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("CLI only\n"); }
require dirname(__DIR__) . '/inc/bootstrap.php';
if ($argc < 4) { fwrite(STDERR, "Usage: php scripts/create_admin.php username email password\n"); exit(1); }
[$script, $username, $email, $password] = $argv;
if (!preg_match('/^[a-z0-9_]{3,24}$/', $username) || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 14) {
    fwrite(STDERR, "Invalid input. Username 3-24 chars; valid email; password at least 14 chars.\n"); exit(1);
}
$stmt = db()->prepare('INSERT INTO users (username,email,password_hash,role,status,created_at) VALUES (?,?,?,"admin","active",NOW())');
$stmt->execute([$username,$email,password_hash($password,PASSWORD_DEFAULT)]);
$id = (int)db()->lastInsertId();
db()->prepare('INSERT INTO user_profiles (user_id,display_name,created_at,updated_at) VALUES (?,?,NOW(),NOW())')->execute([$id,$username]);
echo "Admin account created. User ID: {$id}\n";
