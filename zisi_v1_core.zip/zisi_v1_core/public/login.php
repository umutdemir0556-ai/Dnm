<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
if (current_user()) redirect('/profile.php');
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $errors[] = 'Enter a valid email address and password.';
    } else {
        $stmt = db()->prepare('SELECT id, username, email, password_hash, role, is_verified, status FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user['password_hash']) || $user['status'] !== 'active') {
            $errors[] = 'The email or password is incorrect.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            redirect('/profile.php');
        }
    }
}
$pageTitle = 'Sign in · Zisi';
require APP_ROOT . '/app/Views/partials/header.php';
?>
<main class="auth-wrap">
  <section class="auth-card">
    <div class="eyebrow">WELCOME BACK</div><h1>Sign in to Zisi</h1>
    <p class="muted">Continue to your private space.</p>
    <?php foreach ($errors as $error): ?><div class="alert"><?= e($error) ?></div><?php endforeach; ?>
    <form method="post" class="form-stack">
      <?= csrf_field() ?>
      <label>Email address<input type="email" name="email" autocomplete="email" required></label>
      <label>Password<input type="password" name="password" autocomplete="current-password" required></label>
      <button class="button button-primary" type="submit">Sign in</button>
    </form>
    <p class="form-foot">Have an invitation? <a href="<?= e(url('/register.php')) ?>">Create an account</a></p>
  </section>
</main>
<?php require APP_ROOT . '/app/Views/partials/footer.php'; ?>
