<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
if (current_user()) redirect('/profile.php');
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = strtolower(trim((string)($_POST['username'] ?? '')));
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $inviteCode = strtoupper(trim((string)($_POST['invite_code'] ?? '')));
    if (!preg_match('/^[a-z0-9_]{3,24}$/', $username)) $errors[] = 'Username must be 3–24 characters (letters, numbers, underscore).';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (strlen($password) < 10) $errors[] = 'Password must be at least 10 characters.';
    if ($inviteCode === '') $errors[] = 'An invitation code is required.';
    if (!$errors) {
        try {
            db()->beginTransaction();
            $invite = db()->prepare('SELECT id FROM invitations WHERE code_hash = ? AND status = "active" AND expires_at > NOW() AND uses_count < max_uses FOR UPDATE');
            $invite->execute([hash('sha256', $inviteCode)]);
            $invitation = $invite->fetch();
            if (!$invitation) {
                db()->rollBack();
                $errors[] = 'This invitation code is invalid, expired, or already used.';
            } else {
                $exists = db()->prepare('SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1');
                $exists->execute([$email, $username]);
                if ($exists->fetch()) {
                    db()->rollBack();
                    $errors[] = 'That email address or username is already registered.';
                } else {
                    $insert = db()->prepare('INSERT INTO users (username, email, password_hash, role, status, created_at) VALUES (?, ?, ?, "user", "active", NOW())');
                    $insert->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT)]);
                    $userId = (int)db()->lastInsertId();
                    db()->prepare('INSERT INTO user_profiles (user_id, display_name, created_at, updated_at) VALUES (?, ?, NOW(), NOW())')->execute([$userId, $username]);
                    db()->prepare('UPDATE invitations SET uses_count = uses_count + 1, used_at = NOW() WHERE id = ?')->execute([(int)$invitation['id']]);
                    db()->commit();
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $userId;
                    redirect('/profile.php');
                }
            }
        } catch (Throwable $e) {
            if (db()->inTransaction()) db()->rollBack();
            error_log((string)$e);
            $errors[] = 'Registration could not be completed. Please try again.';
        }
    }
}
$pageTitle = 'Join Zisi';
require APP_ROOT . '/app/Views/partials/header.php';
?>
<main class="auth-wrap">
  <section class="auth-card">
    <div class="eyebrow">INVITATION REQUIRED</div><h1>Create your account</h1>
    <p class="muted">Zisi is currently open to invited members only.</p>
    <?php foreach ($errors as $error): ?><div class="alert"><?= e($error) ?></div><?php endforeach; ?>
    <form method="post" class="form-stack">
      <?= csrf_field() ?>
      <label>Invitation code<input name="invite_code" autocomplete="off" required></label>
      <label>Username<input name="username" minlength="3" maxlength="24" pattern="[A-Za-z0-9_]+" autocomplete="username" required></label>
      <label>Email address<input type="email" name="email" autocomplete="email" required></label>
      <label>Password<input type="password" name="password" minlength="10" autocomplete="new-password" required></label>
      <button class="button button-primary" type="submit">Create account</button>
    </form>
    <p class="form-foot">Already a member? <a href="<?= e(url('/login.php')) ?>">Sign in</a></p>
  </section>
</main>
<?php require APP_ROOT . '/app/Views/partials/footer.php'; ?>
