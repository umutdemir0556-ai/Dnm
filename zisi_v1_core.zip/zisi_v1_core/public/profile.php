<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_login();
$stmt = db()->prepare('SELECT u.username, u.email, u.is_verified, p.display_name, p.bio FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE u.id = ?');
$stmt->execute([current_user_id()]);
$profile = $stmt->fetch();
$pageTitle = 'Your profile · Zisi';
require APP_ROOT . '/app/Views/partials/header.php';
?>
<main class="content-wrap">
  <section class="profile-card">
    <div class="profile-avatar"><?= e(strtoupper(substr($profile['username'], 0, 1))) ?></div>
    <div><div class="eyebrow">YOUR ZISI PROFILE</div><h1><?= e($profile['display_name'] ?: $profile['username']) ?> <?= $profile['is_verified'] ? '<span class="verified" title="Verified">✓</span>' : '' ?></h1><p class="muted">@<?= e($profile['username']) ?></p></div>
    <div class="profile-details"><p><?= e($profile['bio'] ?: 'Your bio will appear here when profile editing is added.') ?></p><p class="muted"><?= e($profile['email']) ?></p></div>
    <form method="post" action="<?= e(url('/logout.php')) ?>"><?= csrf_field() ?><button class="button button-quiet" type="submit">Sign out</button></form>
  </section>
  <div class="notice"><strong>Core release preview</strong><p>Account creation and invitation validation are active. Following, messaging, notifications and profile editing are planned for subsequent development phases.</p></div>
</main>
<?php require APP_ROOT . '/app/Views/partials/footer.php'; ?>
