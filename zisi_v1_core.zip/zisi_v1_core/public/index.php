<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';

$pageTitle = 'Zisi — Your private social network';
$user = current_user();
require APP_ROOT . '/app/Views/partials/header.php';
?>
<main class="landing">
  <section class="hero">
    <div class="eyebrow"><span class="pulse"></span> PRIVATE SOCIAL NETWORK</div>
    <h1>Your circle.<br><span>Your space.</span></h1>
    <p>Zisi is a private place to connect with people you know. Membership is invitation-only.</p>
    <div class="hero-actions">
      <?php if ($user): ?>
        <a class="button button-primary" href="<?= e(url('/profile.php')) ?>">View your profile</a>
      <?php else: ?>
        <a class="button button-primary" href="<?= e(url('/login.php')) ?>">Sign in</a>
        <a class="button button-quiet" href="<?= e(url('/register.php')) ?>">Join with an invitation</a>
      <?php endif; ?>
    </div>
    <div class="hero-meta"><span>INVITATION ONLY</span><span>·</span><span>BUILT AROUND PRIVACY</span></div>
  </section>
  <section class="feature-strip">
    <article><span class="feature-icon">01</span><h2>People first</h2><p>A considered space for your own circle.</p></article>
    <article><span class="feature-icon">02</span><h2>Private by design</h2><p>Access is controlled from the first step.</p></article>
    <article><span class="feature-icon">03</span><h2>Less noise</h2><p>Useful connections without the clutter.</p></article>
  </section>
</main>
<?php require APP_ROOT . '/app/Views/partials/footer.php'; ?>
